# CometLocal Architecture

Proyecto base para agente tipo Comet local.
