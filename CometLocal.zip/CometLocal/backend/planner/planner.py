class Planner:
    def plan(self, user_message: str) -> str:
        return f"(PLAN STUB) Ejecutaría una serie de pasos para: '{user_message}'"
